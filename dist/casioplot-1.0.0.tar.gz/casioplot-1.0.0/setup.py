from setuptools import setup

setup(
    name='casioplot',
    version='1.0.0',
    packages=[],
    url='https://github.com/uniwix/casioplot',
    license='',
    author='uniwix',
    author_email='odevlo.me@gmail.com',
    description='This module allows to use casioplot module on a computer.',
    python_requires=">=3.10",
)
